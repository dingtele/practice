abstract class FishD{}

class Anchovy extends FishD
{
    public boolean equals(Object O)
}

class Salmon extends FishD
{

}

class Tuna extends FishD
{
    
}